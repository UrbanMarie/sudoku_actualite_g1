--------------------------------------------------------------------------------
Sudoku Solver
--------------------------------------------------------------------------------
Andnotor, developpez.net Defi N�5
================================================================================

Introduction:
-------------

Voici ma petite application relative au d�fi N�5 de developpez.net

Cette application � volontairement �t� d�velopp�e en Delphi 2007 (et non 2009)
en esp�rant que la compilation passera sans trop de modifs sur des versions plus
anciennes.

A noter que D2009 m'aurait sans doute permis de me passer d'unit�s suppl�mentaires
pour la gestion des images PNG.


================================================================================

Principe du solver:
-------------------

J'admets que dans ce d�fi, ce n'�tait pas la partie qui m'amusait le plus ! Je
me suis donc content� d'un "brut-force" pur et dur. La simple application de
formules math�matiques ne m'int�ressant qu'� moiti�.

On peut tout de m�me not� que le "brut-force" n'est jamais pris en d�faut et que
les temps de r�solutions sont tout � fait acceptables (0.84 � 0.95 ms chez moi
pour AI Escargot)

Les chiffres accept�s par cellule (ligne, colonne ou r�gion) sont cod�s sur un
word. Les bits 1 � 9 repr�sentant les chiffres.
L'acceptation d'un chiffre se fait par un simple AND sur les masques de la
cellule, de la ligne, de la colonne et de la r�gion.

Au d�marrage de la r�solution, une grille de travail est cr��e ne contenant
effectivement que les cellules � calculer. Cette grille est un tableau de
pointeurs pointant sur les cellules de la grille statique.


================================================================================

Interface:
----------

La premi�re chose que je me suis demand�e est: "Comment rendre cette interface
attractif ?" Et la premi�re chose qui m'est venue � l'esprit est: "Et si je
faisait parler HAL ?"

(HAL �tant l'ordinateur du film "2001 l'odyss�e de l'espace" et accessoirement
mon avatar sur le site developpez.net :-)


================================================================================

Affichage:
----------

Je n'avais aucune envie de me lancer dans un d�veloppement OpenGL ou DirectX.
(et de toute fa�on, je n'allais pas m'amuser � r�ecrire les headers, le code
tiers n'�tant pas admis). Je me suis donc content� d'une gestion de fen�tres
"Layered" et au final, vous le constaterez, les animations sont tout � fait
cr�dibles.

L'unit� LayeredImage.pas contient une classe se chargeant de la gestion compl�te
de l'affichage. Les diff�rentes fiches ne faisant qu'un Create et un Free sur
une instance de cette classe.

Les fiches d�rivent de TfLayeredForm (LayeredForm.pas) qui impl�mente le
comportement de base propre � cette application.

Chaque animation est g�r�e � partir d'un thread et la synchronisation avec
l'image de la fiche se fait par PostMessage (WM_EFFECT).

Toutes les images sont au format png et incluses dans les ressources.


================================================================================

Son:
----

Les sons �taient � la base bas�s sur la librairie BASS. Mais les conditions du
d�fi ne permettant pas l'utilisation de codes tiers, Une gestion personnelle a
�t� ajout�e.
Elle est bien moins performante et contient certaines limitations au niveau des
types d'encodage des sons (PCM 8 bits 11k non-compress�) et � l'utilisation se
r�v�le moins fluide que BASS (Les effets de l�ch� de chiffre sont synchro (?) et
de petits crachotements se font entendre...). Mais j'admet ne pas avoir pouss�
bien loin mes recherches.

Le r�pertoire Bin contient les deux versions.

Pour recompiler, il suffit d'ajouter (ou supprimer) le code de compilation BASS
dans les options du projet pour passer d'une version � l'autre.

Toutes les sons sont au format wav et inclus dans les ressources. (Sudoku_Res.rc
ou Sudoku_BASS.rc)


================================================================================

Synchronisation images et sons:
-------------------------------

Le principe est assez simple !

Animation:
Une animation est d�marr�e depuis la fiche courante par Play ou PlayRendering
(Uniquement Play depuis une autre fiche). Ce qui d�marre un thread qui va nous
envoyer au minimum trois messages (WM_EFFECT asynchrone par PostMessage): Un au
d�but (esRenderingStart) et un � la fin (esRenderingEnd) de la proc�dure Execute
et un certain nombre (un au minimum) dans la boucle "while not terminated"
(esRenderingRun). Un Sleep dans la boucle nous donne l'interval entre ces messages.

Son (avec BASS):
Un son est d�marr� depuis la fiche courante par Play ou PlaySound. (Uniquement
Play depuis une autre fiche). Comme pr�conis� par l'auteur, un timer vient
cycliquement lire l'�tat du stream. Une petite classe est assign�e � la cr�ation
du canal et inclus ce timer. Un message (WM_EFFECT) est envoy� � la cr�ation de
cette classe (esSoundStart), � chaque interval du timer (esSoundRun) et � la
destruction de la classe (esSoundEnd).

Son (sans BASS)
Bas� sur les fonctions WaveOut.
Play ou PlaySound avec esSoundStart, esSoundRun, esSoundEnd. Sinon, m�me principe
que les animations.

L'ensemble des messages �tant trait� dans la procedure DoEffect. 


================================================================================

R�pertoires:
------------

 +-- Bin                        //Ex�cutable et librairie
 �
 +-- Data                       //Les grilles sauvegard�es
 �
 +-- Images                     //Toutes les images que j'ai cr��es
 �                              //(Sont contenues dans les ressources)
 �
 +-- Sounds                     //Les diff�rents sons
 �                              //(Sont contenues dans les ressources)
 �
 +-- Sudoku.exe                 //Les sources du programme

 
================================================================================

Fiches et unit�s:
-----------------

 +-- uSudoku.pas                        //Le sudoku solver
 �
 +-- Effects.pas                        //Gestion des animations et des effets sonores
 �
 +-- EffectsConst.pas                   //Constantes correspondant � chaque
 �                                      //situation. Permet la synchronisation
 �                                      // et l'encha�nement des sons et animations
 �
 +-- LayeredImage.pas                   //Gestion des fen�tres layered
 �
 +-- LayeredForm.pas (TfLayeredForm)    //Fiche layered impl�mentant le comportement
 �   �                                  //de base des autres fiches
 �   �
 �   +-- Main.pas (TfMain)              //La fiche principale
 �   �
 �   +-- HAL.pas (TfHAL)                //HAL 9000 (Moi ;-)
 �   �
 �   +-- Door.pas (TfDoor)              //La porte qui masque la grille
 �   �
 �   +-- NumberButtons.pas (TfNumberButtons)
 �   �                                  //Les boutons de 1 � 9
 �   �
 �   +-- CommandButtons.pas (TfCommandButtons)
 �   �                                  //Les boutons de commandes
 �   �
 �   +-- DropNumber.pas (TfDropNumber)  //Effet du l�ch� de chiffre
 �
 +-- Display.pas (TfDisplay)            //La zone de textes
 �
 +-- SpeedButtonEx                      //Surcharge du TSpeedButton. Lui permet
 �                                      //de s'afficher lui-m�me sur l'image layered
 �                                      //(N'a pas besoin d�tre install� dans la palette !)
 �
 +-- Bass.pas                           //Les headers de la librairie BASS
 �
 +-- (PNGImage.pas)                     //Gestion des images png
                                        //N'est pas incluse dans le projet, le chemin
                                        //de recherche est d�fini � l'installation
                                        //des ces composants


================================================================================

R�f�rences:
-----------

- Librairie BASS:
  http://www.un4seen.com

- PNGComponents
  http://www.thany.org/article/18/VCL

  
================================================================================

Conclusion:
-----------

La premi�re chose que les gens vont se demander en voyant mon interface est:
"Pourquoi l'a-t-il fait en anglais ?"

Well...

1� La traduction fran�aise de HAL en CARL m'exasp�re !

2� Je n'ai pas trouv� de bande sonore en fran�ais et n'avait aucune envie de
   ripper moi-m�me le film !

3� Je trouvait ridicule d'avoir un commentaire anglais et des textes fran�ais !


Derni�re chose ! La proc�dure de sortie de l'application est assez longue ! Pour
couper court, vous pouvez double-cliquer sur HAL. Mais s'il �tait en train de
parler, il y aura un petit memory leak (Avec ou sans BASS).


Voil� ! Amusez-vous bien et peut-�tre que �a donnera envie � certain d'entre-vous
de revoir le film...




                                                         Andnotor
                                                       Le 8.08.2009

